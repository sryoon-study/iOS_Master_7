//
//  LayoutTestTests.swift
//  LayoutTestTests
//
//  Created by 정재성 on 7/15/25.
//

import Testing
@testable import LayoutTest

struct LayoutTestTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
