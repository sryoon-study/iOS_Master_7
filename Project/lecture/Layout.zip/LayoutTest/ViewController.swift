//
//  ViewController.swift
//  LayoutTest
//
//  Created by 정재성 on 7/15/25.
//

import UIKit
import SnapKit

class TestCell: UICollectionViewCell {
  static let identifider = String(describing: TestCell.self)
  let numberLabel = UILabel()

  override init(frame: CGRect) {
    super.init(frame: frame)
    contentView.addSubview(numberLabel)
    numberLabel.snp.makeConstraints {
      $0.center.equalToSuperview()
    }
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}

enum Seat: Hashable {
  case seat(String)
  case empty
}

class ViewController: UIViewController {
  lazy var collectionView = UICollectionView(
    frame: .zero,
    collectionViewLayout: makeLayout()
  )

  let items = (0..<10).map { _ in
    Array(0..<100)
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    collectionView.register(TestCell.self, forCellWithReuseIdentifier: TestCell.identifider)
    collectionView.register(SectionHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "Header")
    collectionView.dataSource = self

    view.addSubview(collectionView)
    collectionView.snp.makeConstraints {
      $0.directionalEdges.equalToSuperview()
    }
  }

  func makeLayout() -> UICollectionViewLayout {
    UICollectionViewCompositionalLayout { _, environment in
      let containerSize = environment.container.effectiveContentSize
      let contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 20, trailing: 20)
      let spacing: CGFloat = 10
      let width = (containerSize.width - contentInsets.leading - contentInsets.trailing - (spacing * 2)) / 3
      let layoutItem = NSCollectionLayoutItem(
        layoutSize: NSCollectionLayoutSize(
          widthDimension: .absolute(width),
          heightDimension: .fractionalHeight(1)
        )
      )
      let layoutGroup = NSCollectionLayoutGroup.horizontal(
        layoutSize: NSCollectionLayoutSize(
          widthDimension: .absolute(containerSize.width - contentInsets.leading - contentInsets.trailing),
          heightDimension: .absolute(width * 1.5)
        ),
        repeatingSubitem: layoutItem,
        count: 3
      )
      layoutGroup.interItemSpacing = .fixed(spacing)

      let section = NSCollectionLayoutSection(group: layoutGroup)
      section.interGroupSpacing = spacing
      section.contentInsets = contentInsets
      section.orthogonalScrollingBehavior = .continuous

      let boundaryItem = NSCollectionLayoutBoundarySupplementaryItem(
        layoutSize: NSCollectionLayoutSize(
          widthDimension: .fractionalWidth(1),
          heightDimension: .absolute(50)
        ),
        elementKind: UICollectionView.elementKindSectionHeader,
        alignment: .top
      )
      section.boundarySupplementaryItems = [boundaryItem]
      return section
    }
  }
}

extension ViewController: UICollectionViewDataSource {
  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return items.count
  }
  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return items[section].count
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TestCell.identifider, for: indexPath) as! TestCell
    let item = items[indexPath.section][indexPath.item]
    cell.numberLabel.text = "\(item)"
    cell.backgroundColor = UIColor(hue: .random(in: 0...1), saturation: 1, brightness: 1, alpha: 1)
    return cell
  }

  func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
    let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "Header", for: indexPath) as! SectionHeader
    headerView.titleLabel.text = "Section \(indexPath.section)"
    return headerView
  }
}

class SectionHeader: UICollectionReusableView {
  let titleLabel = UILabel()

  override init(frame: CGRect) {
    super.init(frame: frame)
    addSubview(titleLabel)
    titleLabel.snp.makeConstraints {
      $0.directionalEdges.equalToSuperview()
    }
  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}

#Preview {
  UINavigationController(rootViewController: ViewController())
}
