//
//  ViewController.swift
//  CompositionalLayout
//
//  Created by 정재성 on 7/15/25.
//

import UIKit
import SnapKit
import Then

enum Seat: Hashable {
  case seat(String)
  case empty
}

class ViewController: UIViewController {
  private var seatInfo: [[Seat]] = []

  private lazy var collectionView = UICollectionView(frame: .zero, collectionViewLayout: makeCollectionViewLayout()).then {
    $0.register(SeatCell.self, forCellWithReuseIdentifier: SeatCell.identifier)
    $0.register(EmptyCell.self, forCellWithReuseIdentifier: EmptyCell.identifier)
    $0.dataSource = self
    $0.delegate = self
    $0.bouncesVertically = false
    $0.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
    $0.allowsMultipleSelection = true
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
    let seats = """
      AA AAAAAA AA
     BBB BBBBBB BBB
    CCCC CCCCCC CCCC
    DDDD DDDDDD DDDD
    EEEE EEEEEE EEEE
    FFFF FFFFFF FFFF
      GG GGGGGG GG
      HH HHHHHH HH
      II IIIIII II
      JJ JJJJJJ JJ
    KK   KKKKKK   KK
    LLLLLLLLLLLLLLLL
    """

    seatInfo = seats.split(separator: "\n").map {
      $0.enumerated().reduce(into: []) {
        if $1.element.isWhitespace {
          $0.append(.empty)
        } else {
          $0.append(.seat("\($1.element)\($0.count(where: { $0 != .empty }) + 1)"))
        }
      }
    }

    view.addSubview(collectionView)
    collectionView.snp.makeConstraints {
      $0.directionalEdges.equalToSuperview()
    }
  }

  private func makeCollectionViewLayout() -> UICollectionViewLayout {
    let itemSize = CGSize(width: 40, height: 40)
    let item = NSCollectionLayoutItem(
      layoutSize: NSCollectionLayoutSize(
        widthDimension: .absolute(itemSize.width),
        heightDimension: .absolute(itemSize.height)
      )
    )
    let group = NSCollectionLayoutGroup.horizontal(
      layoutSize: NSCollectionLayoutSize(
        widthDimension: .absolute(itemSize.width * 16 + 15),
        heightDimension: .absolute(itemSize.height)
      ),
      subitems: [item]
    ).then {
      $0.interItemSpacing = .fixed(1)
    }
    let section = NSCollectionLayoutSection(group: group).then {
      $0.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 20, trailing: 0)
    }
    return UICollectionViewCompositionalLayout(section: section)
  }
}

extension ViewController: UICollectionViewDataSource {
  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return seatInfo.count
  }

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return seatInfo[section].count
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let seat = seatInfo[indexPath.section][indexPath.row]
    switch seat {
    case .seat(let id):
      let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SeatCell.identifier, for: indexPath) as! SeatCell
      cell.seatId = id
      return cell
    case .empty:
      return collectionView.dequeueReusableCell(withReuseIdentifier: EmptyCell.identifier, for: indexPath)
    }
  }
}

extension ViewController: UICollectionViewDelegate {
  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    let seat = seatInfo[indexPath.section][indexPath.row]
    switch seat {
    case .seat(let id):
      print("\(id) 좌석 선택함")
    case .empty:
      print("빈 공간임")
      collectionView.deselectItem(at: indexPath, animated: false)
    }
  }
}

final class SeatCell: UICollectionViewCell {
  static let identifier = String(describing: SeatCell.self)

  private let seatIdLabel = UILabel()

  @inlinable var seatId: String? {
    get { seatIdLabel.text }
    set { seatIdLabel.text = newValue }
  }

  override var isSelected: Bool {
    didSet {
      backgroundView?.alpha = isSelected ? 1 : 0.25
      seatIdLabel.textColor = isSelected ? .white : .black
    }
  }

  override init(frame: CGRect) {
    super.init(frame: frame)
    backgroundView = UIView().then {
      $0.backgroundColor = .systemBlue
      $0.layer.cornerRadius = 8
      $0.alpha = 0.25
    }

    contentView.addSubview(seatIdLabel)
    seatIdLabel.snp.makeConstraints {
      $0.center.equalToSuperview()
    }
  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}

final class EmptyCell: UICollectionViewCell {
  static let identifier = String(describing: EmptyCell.self)
}

#Preview {
  ViewController()
}
